/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author COM
 */

public class Gregorian_Calendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    GregorianCalendar cal = new GregorianCalendar(2019,Calendar.JANUARY,8);
        GregorianCalendar myBirthday = new GregorianCalendar(1990,Calendar.MARCH,12);
        cal.add(Calendar.DAY_OF_MONTH,100);
        myBirthday.add(Calendar.DAY_OF_MONTH,10000);
        
        System.out.printf("%d %d %d %d",cal.get(Calendar.DAY_OF_WEEK),
                                        cal.get(Calendar.DAY_OF_MONTH),
                                        cal.get(Calendar.MONTH)+1,
                                        cal.get(Calendar.YEAR));
        
        System.out.printf("\n%d %d %d %d",myBirthday.get(Calendar.DAY_OF_WEEK),
                                          myBirthday.get(Calendar.DAY_OF_MONTH),
                                          myBirthday.get(Calendar.MONTH)+1,
                                          myBirthday.get(Calendar.YEAR));
    }

    
}

package lab8_2;

public class Question {
	protected String text;
	protected String answer;
	public String Question[];
	
	public Question(String text){
		this.text=text;
		
	}
	public Question() {
		// TODO Auto-generated constructor stub
	}
	public void setText(String question) {
		text= question;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getText() {
		return text;
	}
	public String getAnswer() {
		return answer;
	}
	public boolean checkAnswer(String response) {
		if (response.equals(answer)) {
			return true;
			}
		return false;
	}
	public void display() {
		System.out.println(text);
	}

}

package lab8_2;

public class NumericQuestion extends Question{
	public NumericQuestion(String text, String answer) {
		super(text, answer);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean checkAnswer(String response) {
		int intresponse = Integer.parseInt(response);
		int answer = Integer.parseInt(super.answer);
		if ((Math.abs(intresponse-answer))<=0.01){
			return true;
		}
		return false;
	}

	
	

}
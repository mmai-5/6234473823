package lab8_2;

import java.util.ArrayList;
public class ChoiceQuestion extends Question{
	private ArrayList<String> choices = new ArrayList<>();
	public ChoiceQuestion(String text) {
		super(text);
		
	}
	public void addChoice(String choice, boolean correct) {
		choices.add(choice);
		if (correct==true) {
			super.setAnswer(choice);
			}
		}
	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
		for (int i =1;i<= choices.size();i++) {
			System.out.println(i+":"+choices.get(i-1));
	
		}
		
	}
	@Override
	public boolean checkAnswer(String response) {
		// TODO Auto-generated method stub
		int responseint = Integer.parseInt(response);
		return super.checkAnswer(choices.get(responseint-1));
		}
	}
	

package lab5_1;

public class Zeller {
	
	private int dayOfMonth;
	private int month;
	private int year;
		public Zeller(int d,int mn, int yr){
			dayOfMonth = d;
			month= mn;
			year = yr;
		}

	public Day getDayofWeek(){	
		Day d = null;
		if (month==1) {
				month =13;
				year--;	
				}
			if(month == 2) {
				month=14;
				year--;
				}
			int q= dayOfMonth;
			int m= month;
			int j = year/100;
			int k = year%100;
			int h = q+26*(m+1)/10+k+k/4+j/4+5*j;
			h= h %7;
		switch(h) {
		case 0: d = Day.SATURDAY; break;
		case 1: d = Day.SUNDAY; break;
		case 2: d = Day.MONDAY; break;
		case 3: d = Day.TUESDAY; break;
		case 4: d = Day.WEDNESDAY; break;
		case 5: d = Day.THURSDAY; break;
		case 6: d = Day.FRIDAY; break;
		
		}
		return d;
	}
}
	
	
	


	
	

		
		
/*	public enum Day()	{
		SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");
	
	}
	
	public double getDayofWeek(int d1,int m1,int y1) {
		int month=m1;
		int year =y1;
		int dayOfMonth= d1;
		if (month==1) {
			month =13;
			year--;	
			}
		if(month == 2) {
			month=14;
			year--;
			}
		int q =dayOfMonth;
		int m= month;
		int j = year/100;
		int k = year%100;
		int h = q+26*(m+1)/10+k+k/4+j/4+5*j;
		h= h %7;
			switch(h) {
			case 0 :System.out.println("S"); break;
			case 1 :System.out.println("M"); break;
			case 2 :System.out.println("TUESDAY.values()"); break;
			case 3 :System.out.println("WEDNESDAY.values()"); break;
			case 4 :System.out.println("THURSDAY.values(")); break;
			case 5 :System.out.println("FRIDAY.values()"); break;
			case 6 :System.out.println("SATURDAY.values()"); break;
			}
				int q =dayOfMonth;
			int m= month;
			int j = year/100;
			int k = year%100;
			int h = q+26*(m+1)/10+k+k/4+j/4+5*j;
			h= h %7;
			switch (h){
			case 0 :System.out.println("Sunday"); break;
			case 1 :System.out.println("Monday"); break;
			case 2 :System.out.println("Tuesday"); break;
			case 3 :System.out.println("Wednesday"); break;
			case 4 :System.out.println("Thursday"); break;
			case 5 :System.out.println("Friday"); break;
			case 6 :System.out.println("Saturday"); break;
	*/
		


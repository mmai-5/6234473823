package lab5_1;
import java.util.Scanner;
public class ZellerTest {

	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);
		System.out.print("Enter Year:");
		int yr = a.nextInt();
		System.out.print("Enter month(1-12):");
		int mn = a.nextInt();
		System.out.print("Enter Day of Month(1-31):");
		int d = a.nextInt();
		Zeller in = new Zeller(d,mn,yr);
		System.out.print("Day of the week is "+in.getDayofWeek());
		
	}

}

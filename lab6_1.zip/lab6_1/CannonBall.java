package lab6_1;

public class CannonBall {
	private double initV, simS,simT,simV;
	public static final double g=9.81;
	public CannonBall(double v){
		initV = v; simV = v;
		}
	public void simulatedFlight() {
		while (true) {
			double t=0,v=simV,s=simS;
			simT++;
			while (t<100) {
				s=s+v*0.01;
				v=v-g*0.01;
				t++;
			}
		if (v<=0) {
			simT--;
			System.out.printf("Final Distance: %.3f ",this.getSimulatedDistance());
			System.out.printf("Total time: %.2f\n",this.getSimulatedTime());
			break;}
		simV=v;simS=s;
		System.out.printf("Distance on %d sec: %.3f\n",(int)simT,simS);
		}
	}
	public double calculusFlight(double t) {
		return(-0.5)*g*simT*simT+initV*simT;
	}
	public double getSimulatedTime() {
		return simT;
		
	}
	public double getSimulatedDistance() {
		double t=0,s=simS,v=simV;
		while (t<100) {
			s=s+v*0.01;
			v=v-g*0.01;
			t++;
			if (v<=0) {
				simT = simT +t*0.01;
				return simS;
			}
			simS=s;
		}
		return 0;
		
	}
		
}
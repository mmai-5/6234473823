package lab3_3;

public class CashRegisterTester {

	public static void main(String[] args) {
		CashRegister x = new CashRegister(7);
		x.recordPurchase(50);
		x.recordPurchase(10);
		x.recordTaxablePurchase(20);
		x.enterPayment(100);
		System.out.println(x.giveChange());
		
		}

}

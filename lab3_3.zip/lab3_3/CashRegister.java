package lab3_3;

public class CashRegister {
	private double payment,purchase,taxRate,taxTotal,change=0;
	public CashRegister(double n) {
		payment=0;
		purchase=0;
		taxRate =n;
	}
	public void recordTaxablePurchase(double amount){
		purchase += amount;
		taxTotal+=amount *(taxRate/100);
		
	}
	public void recordPurchase(double amount){
		purchase += amount;
	}
	public double getTotalTax(){
		return taxTotal;
	
	}
	public void enterPayment(double amount){
		payment+= amount;
	}
	public double giveChange(){
		double change = payment - purchase-taxTotal;
		payment=0;
		purchase=0;
		return change;
	}

	
}

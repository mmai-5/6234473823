module lab7_1 {
}
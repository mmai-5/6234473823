package lab7_1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class Purse {
	private ArrayList<String> coin= new ArrayList<String>();

	public void addCoin(String coinName) {
		coin.add(coinName);
	}
	public String toString() {
	           String  toReturn = "Purse [";
	           
	           for (int i = 0; i <coin.size(); i++)
	           {
	               if(i == (coin.size()-1))
	               {
	                   toReturn += coin.get(i);
	               }
	               else{
	                   toReturn += coin.get(i)+",";       
	               }
	           }
	           toReturn += "]";
	            return toReturn;
		
	}
	public ArrayList<String>reverse(){
		Collections.reverse(coin);
		return coin;
	}
	public void transfer(Purse other) {

		for(String coins : coin){ 
			other.coin.add(coins);
	        }
		Iterator<String> it = coin.iterator();
		while (it.hasNext()) {
		   String i = it.next();
		   it.remove();}
	}
		
	public boolean sameContents(Purse other) {
		boolean same =true;
		if (coin.size()==other.coin.size()) {
			for (int i=0;i<coin.size();i++) {
				if (coin.get(i) != other.coin.get(i)){
					same = false;}				
				}
			}
		else 
			same = false;
		
		return same;
	}
	
	public boolean sameCoins(Purse other) {
		boolean samec =true;
		if (coin.size()!=other.coin.size()) {
			samec=false;}
		for (int i = 0; i<coin.size();i++) {
			if(other.coin.get(i).equals(coin.get(i))) {
				samec=true;}
		}
		return samec;
	}
}

package lab7_1;

public class PurseTester {

	public static void main(String[] args) {
		Purse a = new Purse();
		Purse b = new Purse();
		a.addCoin("Quarter");
		a.addCoin("Dime");
		a.addCoin("Nickle");
		a.addCoin("Dime");
		b.addCoin("Quarter");
		b.addCoin("Dime");
		b.addCoin("Dime");
		b.addCoin("Nickle");
		System.out.println(a);
		System.out.println(b);
		System.out.println(a.sameContents(b));
		System.out.println(a.sameCoins(b));

	}

}

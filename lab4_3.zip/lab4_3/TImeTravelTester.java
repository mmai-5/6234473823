package lab4_3;

import java.util.Scanner;
public class TImeTravelTester {
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter start time: ");
		int St = scan.nextInt();
		System.out.print("Enter end time: ");
		int Et = scan.nextInt();  
		
		TimeInterval c = new TimeInterval(St,Et);
		System.out.printf("%.0f hours %.0f minutes",c.getHours(),c.getMinutes());
     }
}

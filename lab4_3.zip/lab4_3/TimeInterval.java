package lab4_3;

public class TimeInterval {
	 private int StartTime, endTime=0;
	 
	 private int Startmins,StartHr,EndHr, Endmins =0;
	 private int start,end=0;
	 public TimeInterval(int St,int Et) {
	 StartTime = St;
	 endTime = Et;
	 
	 StartHr= St/100;
	 Startmins =St %100;
	 EndHr =Et /100;
	 Endmins = Et%100;
	 
	 end=Endmins+EndHr*60;
	 start=Startmins+StartHr*60;

	 }
	 public double getHours() {
	  return((int)((end-start)/60)); 
	 }
	 public double getMinutes() {
	  return ((end-start)%60);
	 }
}

package lab8_1;

public class Truck extends Car{
	private double maxweight,weight;
	public Truck(double gas, double efficiency,double maxweight,double weight) {
		super(gas,efficiency);
		this.maxweight=maxweight;
		this.weight=weight;
		if (weight>maxweight) {
			weight= maxweight;
		}
		
	}
	public void drive(double distance) {
		
		if (weight>=1 && weight<=10) {
			super.drive(distance+=distance*0.1);
		}
		else if (weight>=11 && weight<=20) {
			super.drive(distance+=distance*0.2);
		}
		else if (weight>20) {
			super.drive(distance+=distance*0.3);
		}

		
	}
}
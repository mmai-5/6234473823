package lab5_2;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
public class Line {
	
	Point2D.Double p1,p2;

	

	 double slope, yIntercept,X;
	 private boolean XC = false;
	 
	 
	 public Line(double x, double y, double m) {
	  slope = m;
	  yIntercept = y-(m*x);
	  
	 } 
	 public Line(double x1,double y1,double x2,double y2) {
	  p1 =new Point2D.Double(x1,y1);
	  p2 = new Point2D.Double(x2,y2);
	  slope =(y2-y1)/(x2-x1);
	  yIntercept = y1 - (slope * x1);
	 }
	 
	 public Line(double m, double b) {
	  slope = m;
	  yIntercept = b ;
	  
	 }
	 
	 public Line(double a) {
	  X=a;
	  slope = 1;
	  yIntercept = 0;
	  XC = true;
	  
	  }
	 public boolean isParallel(Line line) {
	  if (this.slope == line.slope){return true;} 
	  else{return false;}
	 }
	 
	 public boolean equals(Line line) {
	  if (this.slope == line.slope && this.yIntercept == line.yIntercept){return true;}
	  else{return false;}
	  
	 }
	 public boolean isIntersect(Line line) {
	  if (this.isParallel(line) == false){
	   return true;}
	  else {return false;} 
	 }
	 public Point2D.Double getIntersectionPoint(Line line){
		 
		 if(this.isParallel(line)==false) {
			 if(this.XC == true) {
				 double x = this.X;
				 double y = (line.slope*x)+this.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else if (line.XC == true) {
				 double x = line.X;
				 double y = (this.slope*x)+this.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else if (this.slope == 0) {
				 double x = (this.yIntercept-line.yIntercept)/line.slope;
				 double y = this.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else if (line.slope == 0) {
				 double x = (line.yIntercept-this.yIntercept)/this.slope;
				 double y = line.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else if (this.slope==0 && line.XC==true) {
				 double x = line.X;
				 double y = this.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else if (line.slope==0 && this.XC==true) {
				 double x = this.X;
				 double y = line.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
			 
			 else {
				 double x = (-1)*(this.yIntercept-line.yIntercept)/(this.slope-line.slope);
				 double y = (this.slope*x)+this.yIntercept;
				 Point2D.Double point = new Point2D.Double(x,y);
				 return point;}
		 
		 }
		 else {return null;}
	  
	  
	  
	 }
	 
}


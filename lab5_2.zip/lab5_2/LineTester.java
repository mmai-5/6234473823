package lab5_2;

import java.awt.geom.Point2D;

public class LineTester {
	public void print(Line line1, Line line2) {
		Point2D.Double line = line1.getIntersectionPoint(line2);
		System.out.println("Are the two lines equals?: " + line1.equals(line2));
		System.out.println("Are the two lines parallel?: "+line1.isParallel(line2));
		System.out.println("Do the two lines intersect?: "+line1.isIntersect(line2));
		if (line != null) {
			System.out.printf("POint of intersection: %.2f,%.2f",line.getX(),line.getY());
		}
	}

	public static void main(String[] args) {
		LineTester a = new LineTester();
		Line line1 = new Line(1,-24);
		Line line2 = new Line(29,5,53,29);
		a.print(line1, line2);

	}

}

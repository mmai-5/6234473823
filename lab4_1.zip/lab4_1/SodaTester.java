package lab4_1;


import java.util.Scanner;

/**
 *
 * @author usci
 */
public class SodaTester {
    public static void main(String[] args) {
    Scanner a = new Scanner(System.in); 
    System.out.print("Enter height: ");
    double h = a.nextDouble();
    System.out.print("Enter diameter: ");
    double d = a.nextDouble();
    
    SodaCan x = new SodaCan(h,d);
    System.out.printf("Volume : %.2f\n",x.getVolume());
    System.out.printf("Surface area : %.2f",x.getSurfaceArea());
    

}
}

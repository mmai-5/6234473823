package lab4_2;

public class DigitExtractor {
    public int num;
    public DigitExtractor(int anInteger){
        num = anInteger;
    }
    public int nextDigit(){
        int anInt = num%10;
        num = num/10;
        return anInt;
       }
}


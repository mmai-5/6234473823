package lab3_1;

public class InsectPopulation {
	public double insect;
	
	public InsectPopulation(double n){
		insect = n; 
	}
	
	public void breed(){
		insect *=2;
	}

	public void spray(){
		insect *=0.9;
	}
	public double getNumInsect(){
		return(insect);
	}
}

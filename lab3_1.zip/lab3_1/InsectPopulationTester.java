package lab3_1;

public class InsectPopulationTester {
	public double x;
	public static void main(String[] args) {
		InsectPopulation x = new InsectPopulation(10);
		x.breed();
		x.spray();
		System.out.println("Number of insects: "+x.getNumInsect());
		x.breed();
		x.spray();
		System.out.println("Number of insects: "+x.getNumInsect());
		x.breed();
		x.spray();
		System.out.println("Number of insects: "+x.getNumInsect());
		
	}

}

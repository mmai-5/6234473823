package com.example.guessnumber;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener{

    public static final int MAX_NUMBER= 100;
    public static Random RANDOM = new Random();
    private TextView msgTv;
    private EditText et1;
    private Button btn;
    private int numberToFind,numberTries;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        msgTv = (TextView) findViewById(R.id.msg);
        et1 = (EditText) findViewById(R.id.editText1);
        btn = (Button)findViewById(R.id.button2);
        btn.setOnClickListener(this);
        newGame();

    }

    @Override
    public void onClick(View v) {
        if (v ==btn){
            buttonner();
        }

    }
    private void buttonner(){
        int n = Integer.parseInt(et1.getText().toString());
        numberTries++;
        if(n == numberToFind){
            Intent i = new Intent(Main2Activity.this, Main3Activity.class);
            startActivity(i);
            finish(); }
        else if(n>numberToFind){
            msgTv.setText(R.string.too_high); }
        else if(n<numberToFind){
            msgTv.setText(R.string.too_low); }

    }
    private void newGame(){
        numberToFind = RANDOM.nextInt(MAX_NUMBER)+1;
        msgTv.setText(R.string.TextView);
        et1.setText("");
        numberTries=0;
    }
}

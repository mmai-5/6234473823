package lab6_3;
import java.util.Random;
public class CityGrid {
	private int xCoor,yCoor,gridSize,x,y;
	public CityGrid(int x,int y){
		this.xCoor = x/2;
		this.x=x;
		this.yCoor = y/2;	
		this.y=y;
		this.gridSize = x*y;
		
		
		
	}
	public void walk(){
		Random rand = new Random();
		int walk = rand.nextInt(4);
		switch(walk) {
		case 0 : xCoor++;break;
		case 1 : xCoor--;break;
		case 2: yCoor++;break;
		case 3: yCoor--;break;
		}
		
	}
	public boolean isInCity() {
		if ((xCoor>=0 && xCoor<=x) && (yCoor<=y && yCoor>=0)) {
			return true;}
		else {
			return false;}
	}
	public void reset() {
		xCoor=x/2;
		yCoor=y/2;
		
	}
}

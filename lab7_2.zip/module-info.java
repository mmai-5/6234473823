module lab7_2 {
}
package lab7_2;

import java.util.Scanner;

public class MagicSquareTester {
	 public static void main(String[] args) {
			System.out.print("Enter n:");
			Scanner in = new Scanner(System.in);
			int sc = in.nextInt();
			while (sc%2==0) {
				System.out.print("Enter n:");
				sc = in.nextInt();}
			
			MagicSquare t = new MagicSquare(sc);
			System.out.println(t.toString());
	 }

}

package lab3_2;

public class Letter {
	
	private String a,b,c; 
	public Letter(String to, String from) {
		a="Dear "+to+":\n\n";
		c="\nSincerely,\n\n"+from;
	}
	
	
	public void addLine(String line) {
		a=a+line+"\n";
		
	}
	public String getText() {
		return(a+c);
	}
	
	

}

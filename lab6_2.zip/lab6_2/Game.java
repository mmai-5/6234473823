package lab6_2;
import java.util.Scanner;
import java.util.Random;
public class Game {
	public int comP,personP;
	public int cscore,pscore=0;
	public void play() {
		while (Math.abs(cscore-pscore)!=2) {
			System.out.print("Enter 0 for Rock, 1 for PAPER, 2 for SCISSORS: ");
			Scanner in = new Scanner(System.in);
			String per = in.next();
			Random r = new Random();
			comP = r.nextInt(3);
			if (!"0".equals(per) && !"1".equals(per)&&!"2".equals(per)) {
				continue;
			}
			int personP = Integer.parseInt(per);
			String a = null;
			switch (personP) {
			case 0: a = "ROCK";break;
			case 1: a = "PAPER";break;
			case 2: a = "SCISSORS";break;}
			
			System.out.println("You Enter: "+a);
			
			String b = null;
			switch (comP) {
			case 0: b = "ROCK";break;
			case 1: b = "PAPER";break;
			case 2: b = "SCISSORS";break;}
			System.out.println("Computer: "+b);
			
			if (personP==1 && comP==0 || personP==2 &&comP==0 || personP==2 &&comP==1) {
				System.out.println("You win!");
				pscore++;}
			else if (personP==0 && comP==1 || personP==0 &&comP==2 || personP==1 &&comP==2 ) {
				System.out.println("You lose!");
				cscore++;}
			else {
				System.out.println("It's a tie.");}
			}
	System.out.println("---------------------------");
	if (cscore>pscore) {
		System.out.println("Too bad! You lose.");}
	else {
		System.out.println("Congrats! You win!");}
	System.out.println("User score: " +pscore+ "\nComputer score: "+cscore);
	}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author COM
 */
import java.awt.Rectangle;
import java.util.Random;
public class IntersectionPrintor {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Random a = new Random();
       int x1= a.nextInt(50); 
       int y1 = a.nextInt(50); 
       int h1 =a.nextInt(50);
       int w1 =a.nextInt(50);
       int x2 =a.nextInt(50);
       int y2 =a.nextInt(50);
       int h2 =a.nextInt(50);
       int w2 =a.nextInt(50);     
       Rectangle r1 = new Rectangle(x1,y1,h1,w1); 
       Rectangle r2 = new Rectangle(x2,y2,h2,w2);
       System.out.println(r1);
       System.out.println(r2);
       Rectangle r3 = r1.intersection(r2);
       System.out.print("Is the intersected rectangle empty :");
       System.out.println(r3.isEmpty());
    }
    
}

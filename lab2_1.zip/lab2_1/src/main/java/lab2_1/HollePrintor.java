/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;

/**
 *
 * @author COM
 */
public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String st = "Hello, World!";
        st = st.replace("e", "*");
        st =st.replace("o", "e");
        st =st.replace("*","o");
        System.out.println(st);
        
    }
    
}
